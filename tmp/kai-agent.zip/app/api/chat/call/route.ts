import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/prisma';
import { autonomousPlanner } from '@/lib/agent';
import { z } from 'zod';

const schema = z.object({
  message: z.string().min(1)
});

export async function POST(req: Request) {
  const session = await getServerSession();
  if (!session?.user?.email)
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success)
    return new Response(JSON.stringify({ error: 'Invalid input' }), { status: 400 });

  const user = await prisma.user.findFirst({ where: { x_user_id: session.user.email } });
  if (!user || user.balance < 402)
    return new Response(JSON.stringify({ error: 'Payment required' }), { status: 402 });

  await prisma.$transaction([
    prisma.user.update({
      where: { id: user.id },
      data: { balance: { decrement: 402 } }
    }),
    prisma.usageLog.create({
      data: { userId: user.id, endpoint: 'chat', cost: 402 }
    })
  ]);

  const plan = await autonomousPlanner(parsed.data);

  const response = await fetch('https://elizacloud.ai/chat/@kai85', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.ELIZACLOUD_API_KEY}`
    },
    body: JSON.stringify(plan)
  });

  const data = await response.json();
  return new Response(JSON.stringify(data), { status: 200 });
}